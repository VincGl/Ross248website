<?php
session_start()
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Cache-control" content="private" />
  <title>Infinite measures</title>
  <meta name="description" content="Notre solution a pour but de garantir la sécurité des opérateurs des sevices de transport, au travers de divers tests psychotechniques.">
  <meta name="robots" content="index, follow" />
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel="icon" type="image/png" href="../img/logo.png">
</head>