<?php include 'header.php' ?>
<body>
    
<!-- Nav -->
<?php include('nav.php')?>

<!-- Test -->
<div class="videNav"></div>

<form action="" method="post">      
    <div class="containen-fluid">

      <h1>Consultez la Foire aux questions ! </h2>
      <br>

    <div class="accordion">
       <div class="icon"></div>
       <h5>Quels sont les moyens de paiement accepté?</h5>
    </div>
    <div class="panel">
       <p>
       Vous pouvez régler par cartes bancaires,PayPal. 
       </p>
    </div>
     
    <div class="accordion">
       <div class="icon"></div>
       <h5>Quels sont les moyens de paiement accepté?</h5>
    </div>
    <div class="panel">
       <p>
       Vous pouvez régler par cartes bancaires,PayPal. 
       </p>
    </div>
          
    <div class="accordion">
       <div class="icon"></div>
       <h5>Quels sont les moyens de paiement accepté?</h5>
    </div>
    <div class="panel">
       <p>
       Vous pouvez régler par cartes bancaires,PayPal. 
       </p>
    </div>

    <div class="accordion">
       <div class="icon"></div>
       <h5>Quels sont les moyens de paiement accepté?</h5>
    </div>
    <div class="panel">
       <p>
       Vous pouvez régler par cartes bancaires,PayPal. 
       </p>
    </div>

    <div class="accordion">
       <div class="icon"></div>
       <h5>Quels sont les moyens de paiement accepté?</h5>
    </div>
    <div class="panel">
       <p>
       Vous pouvez régler par cartes bancaires,PayPal. 
       </p>
    </div>
          
 </div>
  


<!-- Footer -->
<?php include('footer.php') ?>

<!--<script src="js/script.js"></script>-->
  <script src="../js/app.js"></script>
  <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>
</html>