<footer id="footer">
  <div id="contenuFooter">
    <div class="social">
      <h3>Nos réseaux sociaux</h3><br>
      <h3></h3><br>
      <a href="https://www.facebook.com/ross248" target = "_blank"><ion-icon name="logo-facebook"></ion-icon></a>
      <a href="https://www.instagram.com/ross248/" target = "_blank"><ion-icon name="logo-instagram"></ion-icon></a>
      <a href="https://mailto:ross248@gmail.com" target = "_blank"><ion-icon name="mail"></ion-icon></a>
    </div>
    <div class="txtFooter">
      <p>
        © Infinite measures, 2021 <br><br>
        <a href="../pdf/CGU.pdf" target="_blank">CGU</a> -
        <a href="../pdf/ML.pdf" target="_blank">Mentions légales</a>
      </p>
    </div>
  </div>
</footer>